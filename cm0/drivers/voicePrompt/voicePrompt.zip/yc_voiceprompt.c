#include "yc11xx.h"
#include "yc_voiceprompt.h"
#include "yc_queue.h"
#include "yc_drv_common.h"
#include "yc11xx_qspi.h"
#include "drv_bt.h"

#define VP_EVT_QUEUE_MAX 14
VP_INDEX gQueueVpEvt[VP_EVT_QUEUE_MAX];
QUEUE_HEADER gVpEvtHeader;

#define AUDIO_ALLOW mem_audio_allow
#define VP_ENABLE mem_vp_enable
#define VP_ADDR_ARRAY mem_vp_addr_array
#define VP_DAC_LENGTH 0x2000
#define VP_DAC_START_ADDR0 0x10011000
#define VP_DAC_START_ADDR1 0x10012000
VP_PARAMS gVpparams;

uint16_t gVpPopOffset=4800;

void VP_init()
{
	HWRITE(VP_ENABLE,VP_STOP);
	if (!queue_init(&gVpEvtHeader, (void *)&gQueueVpEvt, sizeof(VP_INDEX), VP_EVT_QUEUE_MAX))
	{
		error_handle();
	}
}

void VP_snd_voiceEvt(VP_INDEX ind)
{
	if (gBRState.topState < BR_POWER_ON)
		return;

	if (ind == VP_POWEROFF)
	{
		queue_clear(&gVpEvtHeader);
		VP_play_voice(VP_POWEROFF);
		return;
	}
	
	if (!Insert_Queue(&gVpEvtHeader,(void *)&ind))
	{
		//put queue is error
		//TO DO
		error_handle();
	}	
}


void VP_play_voice(VP_INDEX ind)
{
	unsigned char temp;
	if (ind >=VP_0 && ind <= VP_9)
	{
		if (!Bt_CheckHFPIsIncomming())
			return;
	}

	//todo close dac
	Lpm_LockLpm(VP_LPM_FLAG);
	HWRITE(VP_ENABLE,VP_START);
	HWRITE(AUDIO_ALLOW,0);

	//stop dac
	HWRITE(0x8106,0);
	//stop adc
	HWRITE(0x803b,0x50);
	//stop cvsd
	HWRITE(0x80f5,0);

	if (ind != VP_POP){
		gVpparams.sVpDataAddr = HR_REG_24BIT(reg_map(VP_ADDR_ARRAY+ind+ind+ind));
		gVpparams.sVpDataOffset =0;
		gVpparams.sMemBlock =0;
		
		//get vp data length
		QSPI_Init();
		OS_ENTER_CRITICAL();
		setRamType(MRAM);
		QSPI_ReadFlashData(gVpparams.sVpDataAddr,0x3,(uint8_t *)&gVpparams.sVpDataLen);
		OS_EXIT_CRITICAL();
		//increase 3 for length
		gVpparams.sVpDataAddr+=3;
	}
	
	//VP_dac_enable();

	//set 48K
	HWRITE(0x896c,0x2d);
	HWRITE(0x896e,0x94);
	temp=HREAD(0x894d);
	temp = temp|0x01;
	HWRITE(0x894d,temp);
	
	HWRITE(0x8978,0xC0);
	HWRITE(0x8979,0xE0);
	HWRITE(0x897c,0x55);
	HWRITE(0x897d,0x08);
	HWRITE(0x8981,0x30);

	temp = HREAD(0x897e);
	temp = temp |0xF0;
	HWRITE(0x897e,temp);
	
	HWRITE(0x897f,0x1F);
	HWRITE(0x8980,0x85);

	HWRITE(0x8106,0x2);
	hw_delay();
	HWRITE(0x8106,0x08);

	
	HWRITEW(0x8100, VP_DAC_START_ADDR0);
	HWRITEW(0x8104,VP_DAC_START_ADDR0);
	HWRITEW(0x8102, VP_DAC_LENGTH-1);

	HWRITE(0x8106,0x18);
	hw_delay();
	HWRITE(0x8106,0x08);
	
	//volume
	HWRITE(0x897a,0x7f);
	HWRITE(0x8108,80);
	
	if (ind != VP_POP){
		HWRITE(0x8107,0x0d);
	}
	else{
		HWRITE(0x8107,0x05);
	}
	HWRITE(0x8106,0x02);
	
	gVpparams.sStopNext = 1;
	//get data from flash
	VP_CheckGetData();
	
	//start dac
	HWRITE(0x897a,0x62);
	HWRITE(0x8106,0x03);
}

void VP_CheckGetData()
{	
	uint16_t wptr ;
	uint16_t rptr;
	uint16_t remaind;

	if (HREAD(VP_ENABLE) == VP_STOP)
		return;
		
	wptr = HREADW(0x8104);
	rptr = HREADW(0x836a);

	if (wptr>rptr)
	{
		remaind = wptr-rptr;
	}
	else if(rptr > wptr)
	{
		remaind = rptr-wptr;
		remaind = 0x2000-remaind;
	}
	else 
		remaind = 0x3ff;

	if (remaind > 0x3ff)
		return;
	
	//if (gVpparams.sVpDataOffset >= gVpparams.sVpDataLen)
	if ( gVpparams.sVpDataLen - gVpparams.sVpDataOffset < 0x1000)
	{
		gVpparams.sStopNext = 0;
		if (queue_is_empty(&gVpEvtHeader))
		{
			//dac stop
			Lpm_unLockLpm(VP_LPM_FLAG);
			HWRITE(VP_ENABLE,VP_STOP); 
			Bt_SndCmdRecoverAudio();
		}
		else
			return;
	}
	
	QSPI_Init();
	if (gVpparams.sMemBlock == 0)
	{
		OS_ENTER_CRITICAL();
		setRamType(MRAM);
		QSPI_ReadFlashData(gVpparams.sVpDataAddr+gVpparams.sVpDataOffset
			,0x1000,(uint8_t *)VP_DAC_START_ADDR0);
		OS_EXIT_CRITICAL();
		gVpparams.sMemBlock=1;
		gVpparams.sVpDataOffset+=0x1000;
		HWRITEW(0x8104,0x2000-2);
	}
	else
	{	
		OS_ENTER_CRITICAL();
		setRamType(MRAM);
		QSPI_ReadFlashData(gVpparams.sVpDataAddr+gVpparams.sVpDataOffset
			,0x1000,(uint8_t *)VP_DAC_START_ADDR1);
		OS_EXIT_CRITICAL();
		gVpparams.sMemBlock=0;
		gVpparams.sVpDataOffset+=0x1000;
		HWRITEW(0x8104,0x3000-2);
	}
}


void VP_polling_Queue()
{
	VP_INDEX *evt_ele;

	VP_CheckGetData();

	if (gVpparams.sStopNext)
		return;
	
	if (!queue_is_empty(&gVpEvtHeader))
	{
		evt_ele = (VP_INDEX *)Delete_Queue(&gVpEvtHeader);
		VP_play_voice(*evt_ele);
	}
}

/**
void VP_dac_enable()
{
	unsigned char temp;

	//set 48K
	HWRITE(0x896c,0x2d);
	HWRITE(0x896e,0x94);
	temp=HREAD(0x894d);
	temp = temp|0x01;
	HWRITE(0x894d,temp);
	
	HWRITE(0x8978,0xC0);
	HWRITE(0x8979,0xE0);
	HWRITE(0x897c,0x55);
	HWRITE(0x897d,0x08);
	HWRITE(0x8981,0x30);

	temp = HREAD(0x897e);
	temp = temp |0xF0;
	HWRITE(0x897e,temp);
	
	HWRITE(0x897f,0x1F);
	HWRITE(0x8980,0x85);
	
	HWRITEW(0x8100, VP_DAC_START_ADDR0);
	HWRITEW(0x8104,VP_DAC_START_ADDR0);
	HWRITEW(0x8102, VP_DAC_LENGTH-1);

	//volume
	HWRITE(0x897a,0x64);
	//HWRITE(0x897b,0xa8);
	HWRITE(0x8108,80);
	//HWRITE(0x8109,80);

	HWRITE(0x8107,0x0d);
	HWRITE(0x8106,0x02);
	
}
**/
bool VP_Check_Queue_Is_empty()
{
	return queue_is_empty(&gVpEvtHeader);
}

